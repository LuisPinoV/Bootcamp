from django.contrib import admin

from .models import DatosModel

admin.site.register(DatosModel)
